# MHO QUANTA LTD — 3I/ATLAS First Light Package

Files included:
- MQUDE_First_Light.tex
- MHO_QUANTA_LOGO.png
- fig1_range_vs_time.png
- fig2_deltaR.png
- fig3_gr_vs_mqude_residual.png
- First_Light_Telemetry_trimmed.csv

Compile LaTeX with `pdflatex MQUDE_First_Light.tex` or Overleaf.
